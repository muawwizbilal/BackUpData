// var text = "hello world world";
// console.log(text.replace(/world/g,"guys"))

// var date = new Date();
// console.log (date.getDate());

// var datemy = new Date("Jan 12 2009")
// console.log(datemy)

// var userName = document.getElementById("userName")
// function getname(){
//     var res = userName.value;
//     console.log(res)
// }


 function fillCity() {
    
    var cityName;
    
    var zipEntered = document.getElementById("zip").value;
    
    switch (zipEntered) {
    
    case "60608" :
    
    cityName = "Chicago";
    
    break;
    
    case "68114" :
    
    cityName = "Omaha";
    
    break;
    
    case "53212" :
    
    cityName = "Milwaukee";
    
    }

    document.getElementById("city").value = cityName;
     }

console.log(document.childNodes[1].childNodes[1].childNodes[3].childNodes[3].value)

var obj = {
    userName : "muawwiz",
    age : 13,
    city : "karachi"

}
console.log(obj.userName + obj['age'])

