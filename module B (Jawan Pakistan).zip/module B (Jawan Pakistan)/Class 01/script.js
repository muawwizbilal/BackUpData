
// if (c === d){
//     if (x===y) {
//         g = h;
//     }
//     else if (a===b){
//   g =h;
//     }
//     else{
//         e =f;
//     }
// }
// else{
//     e =f ;  
// }


// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.pop();
// console.log(arr)
// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.push("bilal","masood");
// console.log(arr)
// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.shift();
// console.log(arr)
// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.unshift('mustufa','hamza');
// console.log(arr)
// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.splice(1,1)
// var arr = ['muawwiz','muaz','ibraheem','musab','zarrar'];
// arr.splice(1,1,"karachi")
// console.log(arr)

// var cities = ['karachi','peshawar','islamabad','lahore','hyderabad'];
// //      
// for (var i = 0; i <  cities.length; i++){
//     if(cities[i] == "islamabad"){
//         console.log("found" + i)
//         break;
//     }else{
// console.log("not found" + i)
//     }
// }
