import React, { useState, useEffect } from 'react';
import axios from 'axios';
import css from './index.css'

function App() {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const handleInputChange = event => {
    setInputValue(event.target.value);
  }

  const handleFormSubmit = event => {
    event.preventDefault();
    setLoading(true);
    axios.get(`https://api.github.com/users/${inputValue}`)
        .then(response => {
          setUserData(response.data);
        })
        .catch(err => {
          console.log('error',err)
        })
        .finally(() => {
          console.log("finally")
          setLoading(false);
        });
  }

  if (loading) return <p className='loading'>Loading...</p>;

  return (
    <div>
      <form onSubmit={handleFormSubmit}>
        
        <input type="text" value={inputValue} onChange={handleInputChange} placeholder="Enter Github username" className='input'/>
        <button type="submit">Search</button>
      </form>
      { userData && <div className='data'>
     
        <p>Username: {userData.login}</p>
        <p>ID: {userData.id}</p>
        <p>Followers: {userData.followers}</p>
       <p>Location :{userData.location}</p>
       <p>Bio : {userData.bio}</p>
       <a href={userData.html_url} target="_blank">View Profile</a><br></br>
       <img src={userData.avatar_url} alt="Cannot Get Image" className='Image'/>
        </div>
        }
    </div>
  );
}

export default App;
