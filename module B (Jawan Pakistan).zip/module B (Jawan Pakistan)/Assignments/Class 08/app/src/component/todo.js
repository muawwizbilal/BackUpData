import React, { useState } from 'react';
import './index.css';
const TodoList = () => {


function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div>
      {isLoggedIn ? <LogoutButton /> : <LoginButton />}
    </div>
  );
}

  const [todos, setTodos] = useState([]);
  const addTodo = (text) => {
    setTodos([...todos, { text }]);
  }
  const deleteTodo = (index) => {
    setTodos(todos.filter((todo, i) => i !== index));
  }
  
  return (
    <div>
      <form onSubmit={(event) => {
        event.preventDefault();
        const todoText = event.target.elements.todo.value;
        addTodo(todoText);
        event.target.elements.todo.value = '';
      }}>
        <input type="text" name="todo" />
        <button type="submit">Add Todo</button>
      </form>
      <ul>
        {todos.map((todo, index) => (
          <li key={index}>
            {todo.text}
            <button onClick={() => deleteTodo(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
export default TodoList;
