import React, { useState } from 'react';

function ToDoList() {
  const [todoItems, setTodoItems] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  function addTodo(todoText) {
    setTodoItems([...todoItems, { text: todoText, completed: false }]);
  }
  function editTodo(index,val) {
    const newTodoItems = prompt("Enter New Value",val);
    todoItems[index] = newTodoItems;
    editTodo([...todoItems])
    console.log(val,"val")
    
  }
  function deleteTodo(index) {
    const newTodoItems = [...todoItems];
    newTodoItems.splice(index, 1);
    setTodoItems(newTodoItems);
    
  }

  return (
    <div>
      {isLoggedIn ? (
        <button className='btn' onClick={() => setIsLoggedIn(false)}>Logout</button>
      ) : (
        <button className='btn'onClick={() => setIsLoggedIn(true)}>Login</button>
      )}
      {isLoggedIn && (
        <div>
          <form onSubmit={event => {
            event.preventDefault();
            addTodo(event.target.elements.todoText.value);
            event.target.elements.todoText.value = '';
          }}>
            <input name="todoText" className='input'/><br />
            <button type="submit">Add To-Do</button>
          </form>
          <ul>
            {todoItems.map((item, index) => (
              <li key={index}>
             
                <button onClick={() => editTodo(index,{})}>Edit</button>

                <button onClick={() => deleteTodo(index)}>Delete</button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default ToDoList;
