import React from "react";
import Todo from "./todo";
function Home() {
  return (
    <>
    <Todo/>
    </>
  );
}

export default Home;