fetch('https://fakestoreapi.com/products/')
        .then(res => res.json())
        .then((json) => {
                for (var x in json) {
                        document.getElementById('api').innerHTML += `
        <div class="card" style="width: 18rem;">
        <img src="${json[x].image}" class="card-img-top edit" alt="...">
        <div class="card-body">
          <h5 class="card-title">${json[x].title}</h5>
          <p class="card-text">${json[x].description}</p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">$ ${json[x].price}</li>
          <br>
       /ul>
       <button type="button" class="btn btn-success" onclick="cart()">Add To Cart</button>

        <br>
        <br>
</div>
 <br>     
        <br>
        <br>
`

                }
        })
        .catch((error) => {
                console.log(`The ERROR ${error}`)
        })






