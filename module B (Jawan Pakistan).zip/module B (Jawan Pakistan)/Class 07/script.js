// this in js
// method --> object
// function --> global

// function Userdata(names,age){
//     this.names = names;
//     console.log(names,age)
// }
// var Userdata = new Userdata("mz",14)


// var userObj = {
//     name : 'muawwiz',
//     age: '14',
//     education : ['olevels','nothing'],
//     getEdu : function (){
//         console.log(this)
//     },
//     getData(){
//         this.education.forEach((e)=> console.log(e,this.education)) // only work for foreach
//     }
// }
// console.log(userObj.getData())

// const no = prompt('Enter A Number')
// alert((no % 2 == 0) ? "Even Number" : "Odd Number")

// class Homes {
//     constructor(roomOne,roomtwo,diningroom) {
//         this.roomOne = roomOne; // = "Master Room"; // one way
//         this.roomTwo = roomtwo;
//         this.diningRoom = diningroom;


//     }
//     messages(){
//         console.log(`Message Method ${this.roomOne} ${this.roomTwo} ${this.diningRoom}`)
//     }
// }
// let homeOne = new Homes("Master Room","second room","dining room"); //second way
// // homeOne.roomOne = "Master Room" //third way
// console.log(homeOne.messages())


class Person { 
    constructor(name,occupation) {
        this.name = name;
        this.occupation = occupation;
    }
  
 greet(){
    console.log(`hello ${this.name}`)
    console.log(`Occupation :${this.occupation}`)
 }
}

class Student extends Person {

    constructor(name,occupation) {
        
        super(name);
        this.occupation= occupation
    }
    
    greet() {
        
        console.log(`Hello student ${this.name}.`);
        console.log(`Occupation:  + ${this.occupation}`);
    }
}

let p = new Student("Muawwiz","Nothing");
p.greet();
