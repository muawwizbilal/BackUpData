// var map = document.getElementById('map')
// var filter = document.getElementById('filter')

// // map

// var values = [3,5,8,9,2,0];
// var res = values.map(myFunc);
// function myFunc(numbers){
//     return numbers * numbers;
   

// }

// console.log(res)
// map.innerHTML = res.join(' ')
// //filter
// var ages = [22,30,10,17,13,40,25,9,8,3];

// var resfilter = ages.filter(myFunction);
// function myFunction(age){
//     return age >= 18;
 

    
   

// }
// var results = filter.innerHTML = resfilter.join(' ')


// var array = ['b','c','e','p',['y,z,l,k'],'a','d','f'];
// var [one,two,three,four,[five,six]] = array
// console.log(array)


// var obj = 
//     {
//         first : "muhammad",
//         last : "muawwiz",

//         brother : {
//             f : 'ibrahim',
//             l : 'bilal'
//         }
//     }   
   
// var {first,last,brother:{f,l}} = obj
// console.log(obj)


//local storage
// localStorage.setItem('Name','Muawwiz');
// localStorage.setItem('Age','14');
// let namee = localStorage.getItem('Name')
// let age = localStorage.getItem('Age')

// console.log(age)
// console.log(namee)

// localStorage.removeItem('Age')
// localStorage.clear()





function signUp(){
    let email = document.getElementById('email').value
    let userName = document.getElementById('userName').value

    let pass = document.getElementById('pass').value

    let userObj = {
        userName : document.getElementById('email').value,
        email :  document.getElementById('userName').value,
    
         pass : document.getElementById('pass').value
    }

    let res = JSON.stringify([userObj])
    console.log(res)
    localStorage.setItem("usersData",res);
    function check(){
    
        if("usersData   \" ==res ){
            alert("sorry")    
        }
    }
    check()
    



}
function getData(){
    let resu = JSON.parse(localStorage.getItem("usersData"))
    console.log(resu)
}






























