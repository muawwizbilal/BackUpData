import React, { useState } from 'react';

function useTodo() {
  const [todos, setTodos] = useState([]);
  const [doneTodos, setDoneTodos] = useState({});

  function addTodo(todo) {
    setTodos([...todos, todo]);
  }

  function removeTodo(index) {
    setTodos(todos.filter((todo, i) => i !== index));
    setDoneTodos(doneTodos.filter((todo, i) => i !== index));
  }

  function toggleDone(index) {
    let newDoneTodos = {...doneTodos};
    newDoneTodos[index] = !newDoneTodos[index];
    setDoneTodos(newDoneTodos);
  }

  return {
    todos,
    addTodo,
    removeTodo,
    toggleDone,
    doneTodos
  };
}

function TodoList() {
  const { todos, addTodo, removeTodo, toggleDone, doneTodos } = useTodo();

  return (
    <div>
      <form
        onSubmit={e => {
          e.preventDefault();
          addTodo(e.target.todo.value);
          e.target.todo.value = '';
        }}
      >
        <input name="todo" />
        <button type="submit">Add Todo</button>
      </form>
      <ul>
        {todos.map((todo, index) => (
          <li key={index} style={{textDecoration: doneTodos[index] ? 'line-through' : 'none'}}>
            {todo} <button onClick={() => toggleDone(index)}>Done</button>
            <button onClick={() => removeTodo(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;
