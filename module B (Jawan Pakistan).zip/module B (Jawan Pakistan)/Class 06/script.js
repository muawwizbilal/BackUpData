// function saveData() {
//     let name, email, psw;
//     name = document.getElementById("name").value; 
    
//     email = document.getElementById("email").value;
//     psw = document.getElementById("psw").value;
//     let user_records = [];
//     user_records = JSON.parse(localStorage.getItem("users")) ? JSON.parse(localStorage.getItem("users")) : []
//     if (user_records.some((v) => { return v.email == email })) {
//       alert("This Email is Already been registered");
//     }
//     else {
//       user_records.push({
//         "name": name,
//         "email": email,
//         "psw": psw
//       }
//       )
//       localStorage.setItem("users", JSON.stringify(user_records));
//     }
//   }

let fet =fetch('https://fakestoreapi.com/products/')
        .then(res => res.json())
        .then((json) => {
                for (var x in json) {
               
                        document.getElementById('api').innerHTML += `
        <div class="card" style="width: 18rem;">
        <img src="${json[x].image}" class="card-img-top edit" alt="...">
        <div class="card-body">
          <h5 class="card-title">${json[x].title}</h5>
          <p class="card-text">${json[x].description}</p>
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">$ ${json[x].price}</li>
          
       </ul>
       <button type="button" class="btn btn-success btttn" onclick="cart('${json[x].title}','${json[x].price}')">Add To Cart</button>
<br>
        <br>
        <br>
</div>
 <br>     
        <br>
        <br>
`

                }
        })
        .catch((error) => {
                console.log(`The ERROR ${error}`)
        })

  function cart(title,price){
    console.log(title,'$ '+ price)
  var obj = {
    name : title,
    price : price
  }
    let info = localStorage.getItem('addtocart')


    if(!info){
      var string = JSON.stringify([obj])
      localStorage.setItem('addtocart',string)
    


    }else{
    
      var parse = JSON.parse(info)
      parse.push(obj)

      var parse_string = JSON.stringify(parse)
      localStorage.setItem('addtocart',parse_string)
    }




    

  }

  function checkout(){

    var result = confirm('Are You Sure')
    if (result == true){
      console.log("True")
    }

    let info = localStorage.getItem('addtocart')
    
    var data = JSON.parse(info);
    console.log(data)
    var content = '' , total = 0
    data.map((e)=>{
      total = total + Number(e.price)

      content += `${e.name}<br><br><br><br><br><br>`;

    })
    document.getElementById('apitesting').innerHTML= content





  }


