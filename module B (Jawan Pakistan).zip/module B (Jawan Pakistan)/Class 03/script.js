// var arr1 = [1,2,3,4];
// var arr2 = [5,6,7,8,9];
// var arr3 = [10,11,12,13];
// var res = [...arr1,...arr2,...arr3]; //combine
// console.log(res)
// var num = 13;
// var arr4 = [...arr3,14,15]  
// arr4.pop()
// console.log(arr3)
// console.log(arr4)

// var obj = {username : 'muawwizbilal',address:"karachi"}
// var obj2 = {school : "thelabschool",age:14}
// var res1 = {...obj,...obj2,username:"MUAWWIZ"} // MUAWWIZ will overwrite muawwizbilal
// console.log(res1)

// var array = [1,4,5,6]

// function getData(arr,arr2,arr3,arr4){
// console.log(arr,arr2,arr3,arr4)
// }
// getData(...array);
// var arrayone = [6,7,8,8,9]
// function getRes(...args){
//     console.log(args)
//     for (var i=0;i<args.length;i++){
//         if(args[i] == "bilal"){ //1
//             console.log(i)
//         }
//     }

// }
// getRes("mz",'bilal')
// console.log(...arrayone)            

// const numbers = [45, 4, 9, 16, 25];

// for (let x in numbers) {
  
//   console.log(x)
// }

// const cars = ["carolla", "civic", "ferrrai"];

// for (let y of cars) {
  
//   console.log(y)
// }   