import React from 'react'
import Routers from './config/router'
const App = () => {
  return (
    <div>
      <Routers/>
    </div>
  )
}

export default App