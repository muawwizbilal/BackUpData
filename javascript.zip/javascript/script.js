// Data types
    // var myName = "muawwizbilal";
// var myAge = 13;
// console.log(myName)

// typeof operator
// console.log(typeof(myName)); //string    check the data type 


//data type practise
// console.log(9+"10") concatination
// console.log(9-"10") //bug
// 1 = true 0 = false

// null vs undefined  null = useless no work  undefined = value not assigned // data type null : object

// NaN = not a number / property of global object / variable in global scope
// checking
// console.log(isNaN(myName));
// console.log(isNaN(myAge))

// if(isNaN(myName)){
//     console.log('plz type a number')
// }

// assignment operator : simple = 
// var x = 10;
// var y = 10;


// console.log("is both x and y equal or not" + x == y) //bug //wrong
// console.log(`is both x and y equal or not  : ${x == y}`) ; // correct way 
// console.log(x == y) 
// arithmetic operator take numbers in values : +,-,*,/,% : modulus operator
// console.log("Remainder  " + 27%4)

// Increment Operator and Decrement
// ********************************
// 1: x++ : postfix
// var num = 15;
// var newNum = num++ + 5;
// console.log(num);
// console.log(newNum);
// 2: ++x : prefix
// var num = 15;
// var newNum = ++num + 5;
// console.log(num);
// console.log(newNum);
// same --x x--; like above
// ********************************a

// Comparison Operator : return a logical value based on whether the comparison is ture

// var a = 10;
// var b = 19;
// Equal
// console.log(a == b )
// Not Equal
// console.log(a != b); // false : answer
// Greater than
// console.log(a > b);
// Greater than or equal 
// console.log(a >= b);
// less than
// console.log(a < b);
// less than or equal
// console.log(a <= b);

// Logical Operators : used with booleans logical values; return a boolean value
var a = 10;
var b = -30;
var c = -10;
var d = 50;
// logical  AND (&&) : all expressions true if only one will wrong the answer will be wrong; // all should be true  
//  console.log(a > b && b > -50 && b < 0)
// console.log(a > b && b < c && d > a) // true

// Logical OR (||) : all expressions false if only one will true the answer will be true;

// console.log(a < b || b > c || d > a) // false

// Logical Not (!) : true to false & false to true 
// console.log(!((a > b) || (c > b))) // false
// console.log(!true); //simple the answer will be false

//String Operators : Concatenation operator + : concatenates the string values together : returning another string
// console.log("Hello World");
// console.log("Hello " + "World"); //concatenation
// var myName = "muawwiz";
// console.log(myName + " Bilal")



//practice questions
// console.log(9**2) // 9*9 // exponenation operator
// console.log(10 ** -1); 1/10 ***


// var a = 5;
// var b= 10;
// // output b=5; a=10; // swap number 
// var c = b; // c = 10
// b = a; // b =5
// a = c;
// console.log("the value of a " + a)
// console.log("the value of b"   + b)

// var a = 5;
// var b = 10;
// a = a + b; // a = 15
// b = a - b; // b =  5
// a = a - b; // a =10
// console.log("a " + a)
// console.log("b " + b)

// var num1 = 5;
// var num2 = '5';
// console.log(num1 == num2)
//  double equal to only checks the value and triple equals to check value and datatype also
// var num1 = 5;
// var num2 = '5';
// console.log(num1 === num2)

// if else // if rain = umbrella else norain = no umbrella // if false goes to else if true goes to if
// var tomr = 'sunny';  
// if(tomr == 'rain'){
// console.log("take umbrella")
// }else{
// console.log("don't take umbrella")
// }   
// checking leap year
// var year = 2024;
// if(year % 4 === 0 ){
//   if(year % 100 === 0){
//     if(year % 400 ===0){
// console.log("leapyear")
//     }else{
//          console.log("not a leap year   ")
//     }
//   }else{
//     console.log("leap year")
//   }
// }else{
// console.log("not a leap year")
// }
// debugger 

// falsy values : undefined,null,0,"",NaN, // these all values answer is false

//     if(score = 0){
//         console.log("loss")
//     }else{
//     console.log("won")
// }

//conditional ternary operator  only javascript operator that take three operands
// var age = 18;
// if(age > 18){
//     console.log("You are allowed to register")
// }else{
//     console.log("You are not allowed to register")
// }
//short way of if else
// var age = 17;
// console.log((age >= 18) ? "you are allowed to register" : "You are not allowed to register");

// switch statement : The switch statement executes a block of code depending on different cases.
// switch statement efficient than if else

// without switch statement area of shapes
// var area = "rectangle";
// var Pi = 3.142, l=5,b=4,r=3;
// if(area == "circle"){
//   console.log("the area of circle is : " + Pi*r**2);  
// }else if(area == "triangle"){
//   console.log("the area of triangle is : " + (l*b)/2);  
// }else if(area == "rectangle"){
//   console.log("the area of rectangle is : " + l*b);  
// }else{
//     console.log("enter a valid value")
// }

// var area = "triangle";
// var Pi = 3.142, l=5,b=4,r=3;
// with switch statement
// break statement : terminates the current loop ,switch or label
// switch(area){ 
//   case 'circle':
//     console.log("the area of circle is : " + Pi*r**2);  
//     break;

//   case 'triangle':
//     console.log("the area of triangle is : " + (l*b)/2); 
//     break;

//   case 'rectangle':
//     console.log("the area of rectangle is : " + l*b);  
//     break;

//   default:
//     console.log('enter a valid value');


// }


//while loop : while statement creates a loop that executes a specified statement as long as the test condition evulates to true
// var num = 20;
// // block scope 
// //while loop first check the condition then enters in scope and give the output
// while (num <= 10) {
//   console.log(num) // infinite loop
//   num++;

// }
//do while loop 
// var num = 0;
// do {
//     console.log(num) // infinite loop
//     num++; 
    

//     } while (num <= num);
// di fference between do while loop and while loop :
// The do-while loop is very similar to that of the while loop. But the only difference is that 
// this loop checks for the conditions available after we check a statement

//for loop : similar to while loop
// for (var num = 0; num <= 10; num++) {
//     debugger;
//     console.log(num)

// }

//output 8*1 = 8 8*10 =80
// for(var num = 1; num <= 10; num++){
//         var tableof = 8;
//         console.log(tableof + "*" + num + "=" + tableof * num);

// }

//function : a set of statements that performs a task or calculates a value, 
// function sum(){
//     var a = 10;
//     var b =10;
//     var total = a+b;
//     console.log(total)
// }
// sum(); // important

// function parameter ; are the names listed in the function's definition
// function arguments: are the real values passed to the function
// function sum(a,b){
//     var total = a+b;
//     console.log(total)
// }
// sum(); // important
// sum(20,20);
// sum(20,50);


//function expressions : putting function into vairable 
// function sum(a, b) {
//     var total = a + b;
//     console.log(total)
// }

// var functionExp = sum(20, 20);
// return keyword : value is returned to the owner
// function sum(a, b) {
//     return total = a + b;

// }

// var functionExp = sum(20, 20);
// console.log(functionExp)

// Anonymous function : Anonymous Function is a function that does not have any name associated with it.
// var functionExp = function (a, b) {
//     return total = a + b;

// }

// var sum = functionExp(20,20);
// var sum1 = functionExp(10,10);
// console.log("sum of 20+20 is " + sum)
// console.log(sum > sum1)


// Es6 start
//let vs const vs var

// var = function scope
// let & const = block scope

// updatable similar to var
// let myName = "Muhammad";

// console.log(myName);
// myName = "Muawwiz";

// console.log(myName); 

// not updatable // constant value

// const myName = "Muhammad";
// console.log(myName);
// myName = "Muawwiz";

// console.log(myName); 



// function data() {
//     let myfirstName = "muawwiz"
//     console.log(myfirstName);

//     if(true){
//             let myLastname = "bilal";
//             console.log('inner' + myLastname);
//             console.log('inner' + myfirstName);
//     }
//     console.log('innerouter' + myLastname);
// }

// data();


//template literals
// for(let num = 1; num <= 10; num++){
//     let tableof = 12;
//     console.log(`${tableof} * ${num} = ${tableof * num}`);
// }

//Default Arguments
// function func(a,b=5){
//     return a*b;

// }
// console.log(func(8))

//normal function
// console.log(sum())
// function sum(){
//     let a =5,b=10;
//     let sum = a+b;
//         return `the sum of the two number is ${sum}`;
// }

// fat arrow function : best function in javascript
// const sum = ()  =>  `the sum of two number is ${(a=2)+(b=5)}`; // better than normal function
// console.log(sum());

// Arrays : in array we can store multiple values at only one variable
// var Names = ["musab",14,"muaz",12,"saad",7,"zarrar",11]  
// console.log(Names)
// // traversal in array : navigates through an array
// var Names = ["musab","muaz","saad","zarrar"]  
// console.log(Names[Names.length - 2]); // shortcut for last element
// // if we want to check the length of element .length property will be use . Length value starts from 1 and index no from 0
// console.log(Names.length)

// loop for navigate    
// var Names = ["musab","muaz","saad","zarrar"];

// arrays in for loop
// for(var i = 0; i <Names.length; i++){
//     console.log(Names[i])

// }
//for in loop Es6 ans will be index numbers
// var Names = ["musab","muaz","saad","zarrar"];
// for(let elements in Names){
//     console.log(elements)
// }
// for of loop es6 ans will be data that is in array
// for(let elements of Names){
//     console.log(elements)
// }

// array.prototype.forEach() : calls a function for each element in the array
// if start then will end in the last
// var Names = ["musab","muaz","saad","zarrar"];
//without arrow function
// Names.forEach(function(element, index , array){
//     console.log(`${element},${index},${array}`)
    
// // });
// var Names = ["musab","muaz","saad","zarrar"];
// // with arrow function
// Names.forEach((element, index, array) =>{
//     console.log(`${element},${index},${array}`)
// })
// var Names = ["musab","muaz","saad","zarrar","muawwiz"];
// //indexof : search and filter in an array


// console.log(Names.indexOf("saad"));

// last indexof : return index no from the last 
// var Names = ["musab","muaz","saad","zarrar","muawwiz"];
// console.log(Names.lastIndexOf("saad"));

//array.prototype.includes()
//check that the array contains value return true or false
//search forwad
// var Names = ["musab","muaz","saad","zarrar","muawwiz"];
// console.log(Names.includes("saad",2));
    
//array.prototype.find()
// passing callback function returns found element in the array if some element in the element satisfies the testing
// function, or undefined if not found
// return only one value
// const prices =[200,300,350,600,100,170,650];

//prices < 400

// console.log( prices.find((curr) =>  curr < 400  ) );

// array.prototype.findindex()

// console.log( prices.findIndex((curr) =>  curr > 1400  ) );
// console.log(findelements);
// console.log()
// find method returns undefined and findindex return -1 if not satisfied

// filter method
// array.prototype.filter()
// The filter() method creates a shallow copy of a portion of a given array, filtered down to just the element
// s from the given array that pass the test implemented by the provided function.
// returns emptyy array if not satisfied
    const prices =[200,300,350,600,100,170,650];
    // price < 400;
        const newpricetag =     prices.filter((element , index) => {
            return element > 400;
        })
        console.log(newpricetag)

//sorting an array
// only works on strings
// array.prototype.sort()
// covert element to the sequence e.g . abcdef
// const months = ['January','March','December','Novemeber','June','July','April'];
// console.log(months.sort())
// comparing by converting into strings
// if numbers are sorted as strings however 25 is bigger than 100 becuase 2 is bigger than 1
// coz of this the sort with return an incorrect value or answer
// const array = [1,2,8,5,1110,,16]; 
// console.log(array.sort());

// array crud
// array.prototype.push()
// the push method adds one or more elements to the end of the array and (returns the new length of the array)
// const arr = ['hello','world','HELLO','WORLD','Hi'];
// arr.push('bonjour')
// console.log(arr);

// array.prototype.unshift()
// the unshift method adds one or more elements to then start of the array and returns the new length of the array
// const arr = ['hello','world','HELLO','WORLD','Hi'];
// arr.unshift('bonjour')
// console.log(arr);
// how to tackle this problem
// const myNo = [1,2,3,5];
// myNo.unshift(4,6);
// console.log(myNo)

// array.prototype.pop()
//removes the last element from an array and returns that element. changes the length of an array
// const list = ['bread','eggs','bun','biscuits','oil','rice','wheat','flour','butter','cheese'];
// console.log(list);
// console.log(list.pop()); // returns the element output will be cheese
// console.log(list)
// the shift method removes the first element from an array and return that element .changes the length of an array
// console.log(list)
// console.log(list.shift());
// console.log(list)

// array.prototype.splice();
// add or removes element from an array
// const list = ['bread','eggs','bun','biscuits','oil','rice','wheat','flour','butter','cheese'];
// // always passing index no in splice
// const newListitem = list.splice(list.length, 0, 'Jam');
// console.log(list)
// // deleted element will be shown
// console.log(newListitem);                     
// changing biscuits to Biscuits
// const indexof = list.indexOf('oil');
// if(indexof != -1){
//     const update = list.splice(indexof,1,  'Oil')
// }else{
//     console.log('no such data found')
// }
// console.log(list)

// map reduce method
// array.prototype.map()
// returns a new array containing the results of calling a function in every element in this array
// it returns new array without changing the old array
// const noarr = [1,7,8,3,78,99];
// num > 9
// let Newarr  = noarr.map((curElement,index,arr)=>{
//     return curElement > 9;

// })
// console.log(noarr);
// console.log(Newarr);

// let newArr = noarr.map((curElement,indexno, arr)=>{
//     return `indexno = ${indexno} and the value is ${curElement} belong to ${arr}`

// })
// console.log(noarr)
// console.log(newArr)
// sol1 
// let noarr = [1,7,8,3,78,99];
// let arrSquare = noarr.map((curElement)=>{
//     return Math.sqrt(curElement);   

// })
// console.log(arrSquare);
// sol2
// let noarr = [1,7,8,3,78,99];
// let arr2 = noarr.map((currelement)=>{
//     return currelement * 2;
   




// })
// .filter((curEle)=>{
 
//     return curEle > 10;
// })

// console.log(arr2)
// // Array.prototype.filter()
// // reducer function takes four arguments : accumulator,currentvalue,current index,source array

// let noarr = [5,6,2];
// let sum = noarr.reduce((accumulator,curEle,index,arr)=>{
//     return accumulator += curEle;
    

// })
// console.log(sum) //13


// strings
// javascript string is zero or more characters written inside quotes.
// let myname = "muawwiz";
// let fathername = 'bilal';
// // let fullname = new String("muawwiz bilal");
// console.log(myname);
// console.log(fullname)
//strings.prototype.length()
// property length
// let myNm = "hello";
// console.log(myNm.length)
//Escape Character
// let sen = "my name is \"muawwiz\" ";
// console.log(sen)tor
//if want no mess simply use alternative quotes
// let sen = "my name is 'muawwiz'"
// console.log(sen)

//finding string in a string
//string.prototype.indexof()
// const mydata = "I am muawwiz";
// console.log(mydata.indexOf("a",6))

//string.prototype.lastindexof();
// const mydata = "I am muawwiz";
// console.log(mydata.lastIndexOf("m",3))

//searching for a string in a string
// cannot take more than one value and returns the position
// const mydata = "I am muawwiz";
// let searchdata = mydata.search("muawwiz");
// console.log(searchdata)

// extracting string parts
//slice(start,end) : extracts a part of string and returns
//substring(start,end)
//substr(start,length)

// the last no on the argument will not include. the array will not be change (original.)
// var fruits = 'Banana , Kiwi , Apple'
// // let res = fruits.slice(0,4)
// let res = fruits.slice(7,-2) // last two characters will be removed and it will be go till the end
// console.log(res)

// challenge

// let mytweet = "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."
// let myActual = mytweet.slice(0,280);
// console.log(myActual)
// console.log(myActual.length)

//substring() //similar to slice difference cannot accept negative indexes.
// let fruits = 'apple, banana, mango'
// let res = fruits.substring(0,5);
// console.log(res)

//substr()  similar to slice difference
// let fruits = 'apple, banana, mango'
// // let res = fruits.substr(7,-2); // cannot accept negative indexes
// let res = fruits.substr(-5)
// console.log(res)

// replacing string content
//string.prototype.replace(searchfor , replacedwith)
// the replace method replaces a specified value with another value in a string
// only changes first match case sensitive it dosen't change the original string
// let myemail = "muhammadmuawwiz.2008@gmail.com"
// console.log(myemail)
// let ans = myemail.replace(2008,2009)
// console.log(ans)

// extracting string characters
// 3 methods  chatat() charcodeat() property access [ ]
// charat() method returns the character at a specified index ( position ) in a string
// let str = "HELLO WORLD!"
// let answer = str.charAt(10)
// console.log(answer)

//charcodeat()  : method returns the unicode value of the character at a specified index in a string
// let str = "HELLO WORLD"
// console.log(str.charCodeAt(0))

//challenge time
// let str = "HELLO WORLD"
// let last = str.length -1;   
// console.log(str.charCodeAt(last));

//other useful methods
//1
// let myfirstName = "Muhammad"
// console.log(myfirstName.toUpperCase());
// console.log(myfirstName.toLowerCase())
//2
// let fname = "muhammad"
// let lname = "muawwiz"
// console.log(fname.concat(lname))
// console.log(`${fname} ${lname}`) // best option
// console.log(fname + lname);
// console.log(fname.concat(" " + lname))

// 3
// //String.trim() method removes whitespaces from bothsides
// let es = "                 mz             "
// console.log(es.trim);

// converting string to an array
//split method
// let txt = "a,b,c,d,e,f,g";
// console.log(txt.split(","))
// console.log(txt.split(" "));


// Date and time section 
// the represents milliseconds since 1 january 1970 utc
// four ways to create a new date object
// new Date(); //1
// new Date(year,month,day,hours,minutes,seconds,milliseconds) //2 it takes 7 argments
// new Date(milliseconds)
    // new Date(date strings)

    // let Currdate = new Date(); // complete date and time
    // console.log(Currdate)

    // console.log(new Date().toLocaleString()) // perfect trick
    // console.log(new Date().toString()) // perfect trick

    // console.log(Date.now()) //milliseconds till 1 january 1970

    // var d = new Date(0); //1970
    // var d = new Date(1668524824637)
    // console.log(d.toLocaleString())

    // Dates Method
    // const date  = new Date();
    // console.log(date.toLocaleString());
    // console.log(date.getFullYear());
    // console.log(date.getMonth()) // 0-11 months starts from 0 = january
    // console.log(date.getDate())
    // console.log(date.getDay())

//for fun
// function myFunction() {
//     var d = new Date();
//     d.setHours(6)
//     document.getElementById("demo").innerHTML = d
// }

//maths object in js
//it allows mathematical tasks on numbers
// Math.pi
// console.log(Math.PI) // pi value
// // Math.round // round to the nearest integer from points
// let num = 5.087
// console.log(Math.round(num))
// // Math.pow returns the value of x to the power of y
// console.log(Math.pow(6,7));
// //Math.sqrt : returns the square root of x
// console.log(Math.sqrt(25))
// console.log(Math.sqrt(90))
// console.log(Math.sqrt(5))
// // Math.abs() returns the absolute (positive )value of x
// console.log(Math.abs(-90))
// console.log(Math.abs(-1))
// console.log(Math.abs(-1000))
// console.log(Math.abs(9-100))
// //Math.ceil() rounted up to highest integer if even it is 99.1 it will convert to 100
// console.log(Math.ceil(99.1))
// //Math.floor() opposite of ceil
// console.log(Math.floor(99.9)) // ans will be 99
// //Math.min() : lowest value
// console.log(Math.min(0,-1,200,-100,1000,-90))
// //Math.max() : highest value
// console.log(Math.min(0,-1,200,-100,1000,-90))
// //Math.random() : return a random no between 0 and 1
// console.log(Math.floor(Math.random()*10))
// // Math.trunc() : returns integer part of a number
// console.log(Math.trunc(8.0)) // value will return before point
// console.log(Math.trunc(-10.09232))


// DOM
// const callHeading = document.getElementById('change');
// callHeading.innerHTML = "HI"

// const query = document.querySelector('#change') // if use id then # if class then . // change first element
// query.innerHTML = "(HI)"
// const query = document.querySelectorAll('#change') // if use id then # if class then . // change all elements
// query.innerHTML = "(HI)"

// objects literal : key/value pair data structure 
// storing variables and functions together in one container

// let obj = {
//     myName : "Muhammad Muawwiz",
//     myAge  : 14,
//     getData : function(){
//         console.log(`My name is ${obj.myName} and my age is ${obj.myAge}`)
//     }
// }
// obj.getData()

    // array destructuring

// const childs = ['hamza','zaid','muawwiz'];
// let [noone,notwo,nowthree,mydegree="nothing"] = childs;
// console.log(mydegree)

//    object destructuring
// const childs = {
//     fChild : "Sarim",
//     sChild : "Anas",
//     tChild : "Muawwiz"
// }

// let {fChild,sChild,tChild} = childs;
// console.log(fChild)

// object properties

let myname = "muawwiz"
const myBio = {
    [myname] : "hi",
    [10+4] : "is my age"
}
console.log(myBio)