// const promise1 = new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//             let roll_no = [1,2,3,4,5,6,7,8]
//             resolve(roll_no)
//             // reject('Data not found')

//     },2000)

// })
// const Biodata = (indexdata)=>{
//     return new Promise((resolve,reject)=>{
//         setTimeout((indexdata)=>{
//             let bioData= {
//                 name : "Muawwiz",
//                 age: 14
//             }
//            resolve(`My name is ${bioData.name} and my age is ${bioData.age}. My roll no is ${indexdata}`);



//         },2000,indexdata)
//     })


// }
// promise1.then((rollno)=>{
//     console.log(rollno)
//     return Biodata(rollno[6]);

// }).then((haha)=>{
//     console.log(haha)
// })
// .catch((error)=>{
//     alert(error)

// })


// fetch('https://fakestoreapi.com/products/')
// .then((apidata)=>{
//     console.log(apidata)

//     return apidata.json()

// })

// .then((actualdata)=>{
//         console.log(actualdata)
//        const result = actualdata[0].image
//        document.getElementById('api').innerHTML += `<img src="${actualdata[0].image}" alt="" class="edit">

//        <br>
//        <p>${actualdata[0].price}</p>
    
//        <p>${actualdata[0].description}</p>
//        `
    
// })





fetch('https://fakestoreapi.com/products/')
.then(res=>res.json())
.then((json)=>{
    for(var x in json){
    
        document.getElementById('api').innerHTML += `<img src="${json[x].image}" alt="" class="edit"> 
        <br>
        <p>${json[x].price}</p>
    
        <p>${json[x].description}</p>
        
        `
            
           
            
    }

})
.catch((error)=>{
    console.log(`The ERROR ${error}`)
})