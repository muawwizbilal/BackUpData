const username = document.querySelector('#username');
const saveScoreBtn = document.querySelector('#saveScoreBtn');
const finalScore   = document.querySelector('#finalScore');
const mostRecentScore = document.querySelector('#mostRecentScore');

